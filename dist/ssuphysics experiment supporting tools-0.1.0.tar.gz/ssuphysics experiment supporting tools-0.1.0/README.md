# SSUphysics experiment supporting tools
숭실대학교 물리학과 물리계측실험 수업에서 유용하게 사용할 수 있는 python 페키지입니다.

> 향후 다른 실험 수업에서도 사용할 수 있도록 확장할 예정입니다.

## How to install

## How to use
### getting data

### processing data

### analyzing data

### plot
- rough data plot
- bode plot